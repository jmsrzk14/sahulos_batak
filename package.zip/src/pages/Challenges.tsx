import React from 'react';
import ChallengesSection from '../components/Challenges';

const Challenges = () => {
  return (
    <div className="pt-16">
      <ChallengesSection />
    </div>
  );
};

export default Challenges;