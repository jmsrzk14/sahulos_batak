import React from 'react';
import EcoEducation from '../components/EcoEducation';

const Education = () => {
  return (
    <div className="pt-16">
      <EcoEducation />
    </div>
  );
};

export default Education;